-- Active: 1745606726772@@127.0.0.1@3306@negocio
-- Laboratorio Select
show databases;
-- 1 - Ingrese a la base de datos negocio.
use Negocio;
-- 2 - Ingrese 5 registros aleatorios en cada tabla.
INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
('Juan', 'Pérez', '20-12345678-9', 'Av. Libertador 1000', 'Cliente frecuente'),
('María', 'Gómez', '27-98765432-1', 'Calle Falsa 123', 'Interesada en promociones'),
('Luis', 'Martínez', '30-45678901-2', 'Ruta 45 km 10', 'Nuevo cliente'),
('Ana', 'Lopez', '34-34567890-3', 'Paseo de la Reforma 200', 'Requiere factura A'),
('Carlos', 'Ramírez', '20-23456789-0', 'Calle del Sol 456', 'Compra al por mayor');
INSERT INTO facturas (letra, numero, fecha, monto) VALUES
('A', 1, '2023-04-01', 1500.75),
('B', 2, '2023-04-05', 2500.00),
('C', 3, '2023-04-10', 320.50),
('A', 4, '2023-04-15', 780.25),
('B', 5, '2023-04-20', 600.00);
INSERT INTO articulos (nombre, precio, stock) VALUES
('Laptop', 800.00, 10),
('Mouse', 25.50, 50),
('Teclado', 45.00, 30),
('Monitor', 200.00, 15),
('Impresora', 150.00, 5);

-- 3 - Basándose en la tabla artículos obtener los siguientes listados.

-- a-	artículos con precio mayor a 100
select * from articulos where precio >100;
-- b-	artículos con precio entre 20 y 40 (usar < y >)
select * from articulos where precio>=20 and precio<=40;
-- c-	artículos con precio entre 40 y 60 (usar BETWEEN)
select * from articulos where precio between 40 and 60;
-- d-	artículos con precio = 20 y stock mayor a 30
select * from articulos where precio=20 and stock>30;
-- e-	artículos con precio (12,20,30) no usar IN
select * from articulos where precio=12 or precio=20 or precio=30;
-- f-	artículos con precio (12,20,30) usar el IN
select * from articulos where precio in (12,20,30);
-- g-	artículos que su precio no sea (12,20,30)

select * from articulos where precio not in (12,20,30);
-- h-   artículos que su precio mas iva(21 %) sea mayor a 100
select codigo,nombre,precio, round(precio*1.21) precio_más_iva, stock 
        from articulos where precio*1.21>100;
-- i-   listar nombre de los artículos que no cuesten $100
select nombre from articulos where precio!=100;
-- j- 	artículos con nombre que contengan la cadena 'lampara' (usar like)
select * from articulos where nombre like '%lampara%';
-- k-   artículos que su precio sea menor que 200 y en su nombre 
-- no contenga la letra 'a'
select * from articulos where precio<200 and nombre not like '%a%';
-- 	2- Listar los artículos ordenados por precio de mayor a menor, 
--     y si hubiera precio iguales deben quedar ordenados por nombre.
select * from articulos order by precio desc, nombre;
-- 	3- Listar todos los artículos incluyendo una columna denominada 
--     precio con IVA, la cual deberá tener el monto con el iva del producto.
select codigo, nombre, precio, round(precio*.21,2) monto_iva, 
            round(precio*1.21,2) precio_con_iva, stock from articulos;
-- 	4- Listar todos los artículos incluyendo una columna denominada 'cantidad de cuotas' y otra 'valor de cuota', la cantidad es fija y es 3, 
--     el valor de cuota corresponde a 1/3 del monto con un 5% de interés.
select codigo,nombre,precio, 3 cantidad_de_cuotas, 
            round(precio/3*1.05,2) valor_cuota, stock from articulos;
            
-- comando DML delete
select * from clientes;
delete from clientes where codigo=10;

-- delete masivo
delete from clientes where nombre='Juan';

-- desactiva la protección safe updates en workbench
set sql_safe_updates=0;				-- 0 desactiva		1 activa
set sql_safe_updates=1;

-- borra todos los registros de la tabla
delete from clientes;

-- comando DML Update
select * from clientes;
update clientes set nombre='Gabriela' where codigo=5;

-- update masivo
update clientes set nombre='Maria' where nombre='Mario';
update clientes set nombre='Jacinta';

update clientes set nombre='Miriam', apellido='Salas', comentarios='Debe Plata' where codigo=6;

-- comando DML insert

-- insert normal con lista de campos
insert into clientes(apellido, nombre, cuit, direccion) values
	('Lopez','Diego','93939399','Larrea 234');
-- insert abreviado
insert into clientes values
	(null, 'Javier','Ledesma','40404040','Viel 433','');

-- Usando la base de datos negocio.

-- Basándose en la tabla clientes realizar los siguientes puntos.
use Negocio;
-- 1- 	Insertar 5 clientes en la tabla clientes utilizando el 
--      insert into sin utilizar campos como parte de la sentencias, es decir de la forma simplificada.
INSERT INTO clientes VALUES
(null,'Juan', 'Pérez', '20-12345678-9', 'Av. Rivadavia 1234, CABA', 'Cliente frecuente, siempre paga a término.'),
(null,'María', 'Gómez', '27-98765432-1', 'Calle Corrientes 567, Rosario', 'Nueva cliente, contactar en 15 días para seguimiento.'),
(null,'Carlos', 'Rodríguez', '30-23456789-0', 'Belgrano 890, Córdoba', 'Cliente con historial de demoras en los pagos.'),
(null,'Laura', 'Fernández', '23-34567890-1', 'San Martín 456, Mendoza', 'Cliente VIP, ofrecer descuentos especiales.'),
(null,'José', 'López', '20-45678901-2', 'Independencia 789, Salta', 'Cliente con potencial, enviar catálogo de productos.');
-- 2-	Insertar 5 clientes en la tabla clientes utilizando los campos como parte de la sentencias, es decir de la forma extendida. Completar solo los campos nombre, apellido y CUIT.
INSERT INTO clientes (nombre, apellido, cuit) VALUES
('Ana', 'Martínez', '27-56789012-3'),
('Roberto', 'Sánchez', '30-67890123-4'),
('Silvia', 'Ramírez', '23-78901234-5'),
('Gustavo', 'Díaz', '20-89012345-6'),
('Patricia', 'Castro', '27-90123456-7');
-- 3-	Actualizar el nombre del cliente 1 a Jose.
update clientes set nombre='Jose' where codigo=1;
-- 4-	Actualizar el nombre apellido y cuit del cliente 3 a 
--       Pablo Fuentes 20-21053119-0.
update clientes set nombre='Pablo', apellido='Fuentes', 
        cuit='20-21053119' where codigo=3;

-- 5-	Actualizar todos los comentarios NULL  a ''.
update clientes set comentarios='' where comentarios is null;

-- 6-	Eliminar los clientes con apellido Perez.
delete from clientes where apellido='Perez';
-- 7-	Eliminar los clientes con CUIT Terminan en 0.
delete from clientes where cuit like '%0';

-- Basando se en la tabla artículos, realizar los siguientes puntos.
-- 	8- Aumentar un 20% los precios de los artículos con 
--         precio menor igual a 50.
update articulos set precio=round(precio*1.2,2) where precio<=50;

-- 	9- Aumentar un 15% los precios de los artículos con precio
--      mayor a 50.
update articulos set precio=round(precio*1.15,2) where precio>50;

-- 	10- Bajar un 5% los precios de los artículos con precio 
--      mayor a 200.
update articulos set precio=round(precio*.95,2) where precio>200;

-- 	11- Eliminar los artículos con stock menor a 0.
delete from articulos where stock<0;

-- 12- Agregar a la tabla articulos, los campos stockMinimo y 
--  stockMaximo. (usar alter table add)
use Negocio;
alter table articulos add stockMinimo int;
alter table articulos add stockMaximo int;
describe articulos;
--  13- Completar en los registros los valores de los campos 
--      stockMinimo y stockMaximo (usar update)
--      teniendo en cuenta que el stock mínimo debe ser menor 
--      que el stock máximo.
update articulos set stockMinimo=10;
update articulos set stockMaximo=20;
--  14- Lista los articulos que se deben reponer y que cantidad 
--      se debe reponer de cada articulos.
--      Tener en cuenta que se debe reponer cuando el stock es 
--      menor al stockMinimo y la cantidad de articulos a 
--      reponer es stockMaximo - stock.
select *, stockMaximo-stock cantidad_a_reponer from articulos
        where stock<stockMinimo;

--  15- Calcular el valor de venta de toda la mercaderia que 
--      hay en stock.
select *, round(stock*precio,2) valor_total from articulos;

--  16- Calcular el valor de venta + iva de toda la mercaderia 
--      que hay en stock.
select *, round(stock*precio,2) valor_total, stock*precio*1.21 total_con_iva
                from articulos;


-- Funciones de agrupamiento

-- funcion sum(parámetro)               parámetro numero
select sum(monto) total from facturas;

select  round(sum(stock*precio),2) valor_total, 
        round(sum(stock*precio*1.21),2) total_con_iva
        from articulos;

-- funcion min(parámetro)             parámetro, numero texto fecha
select min(monto) factura_mínima from facturas;
select min(fecha) primer_factura from facturas;
select min(nombre) primer_nombre from clientes;

-- funcion max(parámetro)             parámetro, numero texto fecha
select max(monto) factura_máxima from facturas;
select max(fecha) ultima_factura from facturas;
select max(nombre) ultimo_nombre from clientes; 

-- funcion avg(parámetro)              parámetro
select avg(monto) monto_promedio from facturas;


-- funcion count(*)
select count(*) cantidad_clientes from clientes;
select count(*) cantidad_facturas_A from facturas where letra='A';


-- 1- Crear la tabla 'autos' en una nueva base de datos (Vehiculos) con el siguiente detalle:

-- 	codigo	INTEGER y PK
-- 	marca	VARCHAR(25)
-- 	modelo	VARCHAR(25)
-- 	color	VARCHAR(25)
-- 	anio	INTEGER
-- 	precio	DOUBLE

--  nota: (anio - año) seguramente tu computadora tiene soporte para la letra ñ,
--        pero muchas instalaciones (ej: web host alquilados) pueden que no tenga soporte para esa letra.
-- 		  en programación se acostumbra a usar los caracteres menores a 128 en la tabla ASCII.

-- 2- Agregar el campo patente despues del campo modelo.

-- 3- Cargar la tabla con 15 autos (hacerlo con MySQL WorkBench o el INSERT INTO).
-- 4- Realizar las siguientes consultas:
-- 	a. obtener el precio máximo.
-- 	b. obtener el precio mínimo.
-- 	c. obtener el precio mínimo entre los años 2010 y 2018.
-- 	d. obtener el precio promedio.
-- 	e. obtener el precio promedio del año 2016.
-- 	f. obtener la cantidad de autos.
-- 	g. obtener la cantidad de autos que tienen un precio entre $235.000 y $240.000.
-- 	h. obtener la cantidad de autos que hay en cada año.
-- 	i. obtener la cantidad de autos y el precio promedio en cada año.
-- 	j. obtener la suma de precios y el promedio de precios según marca.
--  k. informar los autos con el menor precio.
--  l. informar los autos con el menor precio entre los años 2016 y 2018.
--  m. listar los autos ordenados ascendentemente por marca,modelo,año.
--  n. contar cuantos autos hay de cada marca.
--  o. borrar los autos del siglo pasado.

