-- ------------------------
-- Definiciones importantes
-- ------------------------


-- Significado de SQL
-- Structured Query Language

-- ANSI SQL
-- En la actualidad el SQL es el estándar de facto de la inmensa mayoría de los SGBD comerciales.
-- Y, aunque la diversidad de añadidos particulares que incluyen las distintas implementaciones
-- comerciales del lenguaje es amplia, el soporte al estándar SQL-92 es general y muy amplio.


-- DDL (DATA DEFINITION LANGUAGE)
-- Create table
-- Alter table
-- Drop table

-- DML (DATA MANIPULATION LANGUAGE)
-- Select
-- Insert
-- Update
-- Delete




-- -----------------------------------
-- Tipos de datos más comunes en MySQL
-- -----------------------------------


-- Tipo de datos Texto de datos más comunes

-- Tipo		Bytes de almacenamiento
-- _______________________________________
-- char(x)		x
-- varchar(x)	x+1

/*
		nombre char(20),
        
        |ANA                 |				20 bytes
		|CARLOS              |				20 bytes
        |MAXIMILIANO         |				20 bytes
        |MARIA TERESA        |				20 bytes
									Total	80 bytes
                                    
		nombre varchar(20)
        |ANA                 |				  3 + 1 = 4  bytes
		|CARLOS              |				  6 + 1 = 7	 bytes
        |MAXIMILIANO         |				 11 + 1 =12  bytes
        |MARIA TERESA        |				 12 + 1 =13  bytes
									Total	36 bytes
*/


-- Tipo de datos Numérico

-- Tipo		Bytes de almacenamiento
-- _______________________________________
-- bool (boolean)	1	(0 es false distinto de 0 es true)
-- tinyint			1	2^8			256
-- smallint			2	2^16		65536
-- mediumint		3	2^24		16777216
-- int (integer)	4	2^32		4294967296
-- bigint			8	2^64		18446744073709551616
-- float			4	 		
-- double			8
-- decimal(t,d)		t+2 

/*
		codigo tinyint			(signed)
        
        |--------|--------|
	  -128		 0       127
        
        codigo tinyint unsigned

		|-----------------|
		0				 255
        
        valor float,
        10/3
        3.333333
        --------
        
        100/3
        33.33333
        --------
        
        valor double
        10/3
        3.33333333333333
        ----------------
        
        100/3
        33.3333333333333
        ----------------
        
        
		precio decimal(8,2)
        999999,99
        ------,--
        
        precio decimal(6,3)
        999,999
        ---,---

*/



-- Tipo de datos Fecha y Hora

-- Tipo		Bytes de almacenamiento
-- _______________________________________
-- date		3	Año Mes Dia ‘2012-10-25’		
-- datetime	8
-- time		3
-- year		1

select 'hola mundo!';
select 2+2;
-- uso del aleas
select 2+2 as valor;
select 2+2 valor;
select 2+2 'valor de resultado';

select PI() 'PI';
select round(PI(),2) 'PI';

select curdate() fecha;			-- date					date 3 bytes
select curtime() hora;			-- hora					time 3 bytes
select sysdate() 'fecha y hora'	-- fecha y hora			datetime 8 bytes


-- 1- Borrar si existe la base de datos Negocio.

-- 2- Crear la base de datos Negocio.

-- 3- Ingresar a la base de datos creada.

-- 4- Crear la tabla Clientes dentro de la base de datos con el siguiente detalle:

-- codigo		int auto_increment y PK
-- nombre		varchar(20) not null
-- apellido		varchar(20) not null
-- cuit			char(13)
-- direccion	varchar(50)
-- comentarios 	varchar(140)

-- PK significa Primary Key

-- 5- Crear la tabla Facturas dentro de la base de datos con el siguiente detalle:

-- Letra		char y PK
-- Numero		integer y PK
-- Fecha		date
-- Monto		double

-- observar que se esta declarando una clave primaria compuesta
-- es decir primary key(letra,codigo)
-- cada campo por si solo no es clave, ni tampoco identifica al registro
-- pero la suma de los dos forman la clave


-- 6- Crear la tabla Articulos dentro de la base de datos con el siguiente detalle:

-- Codigo		integer auto_increment y PK 
-- Nombre 		varchar(50)
-- Precio		double
-- Stock		integer

-- 7- Cargar 5 registros aleatorios en cada tabla.

-- 8- Mostrar las tablas que tiene la base de datos negocio.

-- 9- Describir (detalle de campos - METADATO) cada una de las tablas de la base de datos.

-- 10- Listar los registros de cada tabla.





