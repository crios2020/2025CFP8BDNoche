-- 1- Borrar si existe la base de datos Negocio.
drop database if exists Negocio;

-- 2- Crear la base de datos Negocio.
create database Negocio;

-- 3- Ingresar a la base de datos creada.
use Negocio;

-- 4- Crear la tabla Clientes dentro de la base de datos con el siguiente detalle:

-- codigo		int auto_increment y PK
-- nombre		varchar(20) not null
-- apellido		varchar(20) not null
-- cuit			char(13)
-- direccion	varchar(50)
-- comentarios 	varchar(140)
-- PK significa Primary Key
drop table if exists clientes;
create table clientes(
	codigo int auto_increment primary key,
    nombre varchar(20) not null,
    apellido varchar(20) not null,
    cuit char(13),
    direccion varchar(50),
    comentarios varchar(140)
); 

-- 5- Crear la tabla Facturas dentro de la base de datos con el siguiente detalle:

-- Letra		char y PK
-- Numero		integer y PK
-- Fecha		date
-- Monto		double

-- observar que se esta declarando una clave primaria compuesta
-- es decir primary key(letra,codigo)
-- cada campo por si solo no es clave, ni tampoco identifica al registro
-- pero la suma de los dos forman la clave
drop table if exists facturas;
create table facturas(
	-- letra char(1),
    letra enum ('A','B','C'),
    numero int,
    fecha date,
    monto double,
    primary key(letra,numero)
);

-- 6- Crear la tabla Articulos dentro de la base de datos con el siguiente detalle:

-- Codigo		integer auto_increment y PK 
-- Nombre 		varchar(50)
-- Precio		double
-- Stock		integer
drop table if exists articulos;
create table articulos(
	codigo int auto_increment primary key,
    nombre varchar(50),
    precio double,
    stock int
);

-- 7- Cargar 5 registros aleatorios en cada tabla.
insert into clientes (nombre, apellido, cuit, direccion) values 
	('Ana','Lopez','123456789','Lima 234');
insert into clientes (nombre, apellido, cuit, direccion) values 
	('Juan','Perez','12122222','Viel 934');
insert into clientes (nombre, apellido, cuit, direccion) values 
	('Laura','Gomez','987654321','Medrano 234');
insert into clientes (nombre, apellido, cuit, direccion) values 
	('Javier','Melon','17893333','Mitre 234');
insert into clientes (nombre, apellido, cuit, direccion) values 
	('Melina','Miguel','622222789','Jujuy 211');

insert into facturas (letra,numero,fecha,monto) values ('A',1000,curdate(),40500);
insert into facturas (letra,numero,fecha,monto) values ('A',1001,curdate(),87000);
insert into facturas (letra,numero,fecha,monto) values ('A',1002,curdate(),68500);
insert into facturas (letra,numero,fecha,monto) values ('A',1003,curdate(),48000);
insert into facturas (letra,numero,fecha,monto) values ('A',1004,curdate(),33000);

insert into articulos (nombre,precio,stock) values ('Lampara Led 5w',2500,50);
insert into articulos (nombre,precio,stock) values ('Lampara Led 8W',3500,60);
insert into articulos (nombre,precio,stock) values ('Lampara Led 12w',5500,90);
insert into articulos (nombre,precio,stock) values ('Pinza 100mm',9800,10);
insert into articulos (nombre,precio,stock) values ('Lima 6p',15000,30);

-- 8- Mostrar las tablas que tiene la base de datos negocio.
show tables;
-- 9- Describir (detalle de campos - METADATO) cada una de las tablas de la base de datos.
describe clientes;
describe facturas;
describe articulos;
-- 10- Listar los registros de cada tabla.
select * from clientes;
select * from facturas;
select * from articulos;


-- comando DML Select

-- * comodin que lista todos los campos de la tabla
select * from clientes;
select nombre,apellido from clientes;
select concat(apellido,' ',nombre) nombre_completo, curdate() fecha, apellido, 2+2 
		from clientes;
-- columnas calculadas
select codigo, nombre, precio, precio*0.21 valor_iva from articulos;
-- Desafio agregar en la consulta de articulos 
-- la columna calculada de precio con IVA
select codigo, nombre, precio, precio*1.21 precio_con_iva from articulos;

insert into clientes (nombre,apellido) values ('Laura','Perez');
insert into clientes (nombre,apellido) values ('Laura','Alonso');
-- filtrado usando where
select * from clientes where nombre='Laura';

-- operadores = != <> < <= > >=
-- operadores lógicos and or

select * from clientes where nombre!='Laura';
select * from clientes where nombre<>'Laura';

select * from clientes where codigo>=5;

select * from clientes where nombre='Laura' and apellido='Perez';
select * from clientes where nombre='Laura' or apellido='Perez';

select * from articulos where precio>=5000 and precio<=10000;
select * from articulos where precio<5000 or precio>10000;

-- clausula between, not between
select * from articulos where precio between 5000 and 10000;
select * from articulos where precio not between 5000 and 10000;

select * from clientes 
		where codigo=4 
        or codigo=5 
        or codigo=7 
        or codigo=12;
-- clausula in not in
select * from clientes where codigo in(4,5,7,12);
select * from clientes where codigo not in(4,5,7,12);

-- valores null (desconocido)
insert into clientes (nombre,apellido,direccion) values ('Andrea','Moretti','');
insert into clientes (nombre,apellido,direccion) values ('Ana','Sosa',null);

select * from clientes where direccion is null;
select * from clientes where direccion ='';
select * from clientes where direccion is not null;

select * from clientes where direccion = null; -- error!!!!

-- Las personas que se llaman Laura y Jose
select * from clientes where nombre='Laura' or nombre='Jose';

insert into clientes (nombre, apellido) values ('Maria','Hernadez');
insert into clientes (nombre, apellido) values ('Mariano','Hernadez');
insert into clientes (nombre, apellido) values ('Mariana','Hernadez');
insert into clientes (nombre, apellido) values ('Melina','Hernadez');
insert into clientes (nombre, apellido) values ('Mario','Hernadez');
insert into clientes (nombre, apellido) values ('Marcela','Hernadez');
insert into clientes (nombre, apellido) values ('Marisa','Hernadez');
insert into clientes (nombre, apellido) values ('Mirta','Hernadez');
insert into clientes (nombre, apellido) values ('Marta','Hernadez');
insert into clientes (nombre, apellido) values ('Monica','Hernadez');
insert into clientes (nombre, apellido) values ('Micaela','Hernadez');
insert into clientes (nombre, apellido) values ('Omar','Hernadez');
insert into clientes (nombre, apellido) values ('Marcelo','Hernadez');
insert into clientes (nombre, apellido) values ('Mercedes','Hernadez');
insert into clientes (nombre, apellido) values ('Mariela','Hernadez');
insert into clientes (nombre, apellido) values ('M','Hernadez');
	
-- Busqueda de expresiones con like not like
select * from clientes where nombre like 'm%';
select * from clientes where nombre like 'ma%';
select * from clientes where nombre like 'mar%';
select * from clientes where nombre like '%a';
select * from clientes where nombre like '%ar%';
select * from clientes where nombre not like 'm%';
select * from clientes where nombre like 'm%a';
select * from clientes where nombre like 'm_r%';
select * from clientes where nombre like '_m_r%';
select * from clientes where nombre like '___';
select * from clientes where nombre like '____';
select * from clientes where nombre like '_____%';

-- Order by
select * from clientes;
select * from clientes order by nombre;
select * from clientes order by nombre asc;
select * from clientes order by nombre desc;
select * from clientes order by apellido, nombre;
select * from clientes order by apellido desc, nombre;

-- Limit 
select * from clientes limit 5;
select * from clientes limit 5, 3;































