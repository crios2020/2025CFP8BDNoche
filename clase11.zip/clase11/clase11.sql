-- Uso de JOIN
use negocio;

-- Usando la base de datos negocio (usando todas las tablas).


-- 1- Informar quienes (nombre,apellido) compraron 'lamparas'.
select c.codigo, c.nombre, c.apellido
    from clientes c join facturas f on c.codigo=f.codigo_cliente
    join detalles d on f.letra=d.letra and f.numero=d.numero
    join articulos a on d.codigo=a.codigo
    where a.nombre like '%lampara%';
select * from articulos;
insert into articulos (nombre,precio,stock) VALUES
    ('Lampara Led 5w',8000,20);
select * from detalles;
insert into detalles (letra,numero,codigo,cantidad) VALUES
('b',3,6,10);


-- 2- Informar que articulos compro 'Juan Perez'.
select a.codigo, a.nombre, a.precio, a.stock
    from clientes c join facturas f on c.codigo=f.codigo_cliente
    join detalles d on f.letra=d.letra and f.numero=d.numero
    join articulos a on d.codigo=a.codigo
    where c.nombre='Juan' and c.apellido='Perez';

-- 3- Informar cuantas lamparas se vendieron.
select sum(d.cantidad) cantidad_de_lamparas_vendidas
    from detalles d join articulos a on d.codigo=a.codigo
    where a.nombre like '%lampara%';
-- 4- Informar cuantas unidades se vendieron en total en 
--      cada articulo.
select a.codigo, a.nombre, sum(d.cantidad) cantidad_vendidas
    from detalles d join articulos a on d.codigo=a.codigo 
    group by a.codigo;
-- 5- Informar la lista de artículos vendidos el día de hoy.
select DISTINCT a.codigo, a.nombre, a.precio, a.stock
    from facturas f 
    join detalles d on f.letra=d.letra and f.numero=d.numero
    join articulos a on d.codigo=a.codigo
    where f.fecha=curdate();

INSERT into facturas values ('a',202,curdate(),4000,1);
insert into detalles values ('a',202,3,10);
insert into detalles values ('a',202,4,14);
-- 6- Informar la lista de artículos vendidos en este mes.
select DISTINCT a.codigo, a.nombre, a.precio, a.stock
    from facturas f 
    join detalles d on f.letra=d.letra and f.numero=d.numero
    join articulos a on d.codigo=a.codigo
    where MONTH(f.fecha)=MONTH(curdate());

-- 7- Informar la lista de artículos vendidos en este año y la cantidad vendida.
select DISTINCT a.codigo, a.nombre, a.precio, a.stock, 
    sum(d.cantidad)
    from facturas f 
    join detalles d on f.letra=d.letra and f.numero=d.numero
    join articulos a on d.codigo=a.codigo
    where year(f.fecha)=year(curdate())
    GROUP BY a.codigo;

-- 8 - Informar la cantidad de articulos vendidos a cada cliente
select c.codigo, c.nombre, c.apellido, sum(d.cantidad)
    from clientes c join facturas f on c.codigo=f.codigo_cliente
        join detalles d on f.letra=d.letra and f.numero=d.numero
        join articulos a on d.codigo=a.codigo
        GROUP BY c.codigo;
