-- linea de comentarios
/* bloque de comentarios */
#linea de comentarios no ANSI SQL

show databases;						-- muestra las BDs del server
SHOW DATABASES;
-- ; es el terminador de sentencias
-- CTROL - ENTER para ejecutar
-- el lenguaje no es case sensitive 
-- (no sensible a minúsculas y mayúsulas)

drop database if exists Hotel;		-- borra la bd Hotel

/*
	Indentificadores(nombres) de base de datos
    MySQL sobre windows no es case sensitive en 
		los identificadores
    MySQL sobre linux o mac es case sensitive en 
		los identificadores
    
*/

drop database if exists clase02;

create database clase02;	-- crea la BD clase01

use clase02;				-- activa la BD clase01;

show tables;				-- muestra las tablas de la BD

/*
	Tabla
    columnas - campos
    filas	- registros
*/

drop table if exists clientes;
-- creamos la tabla clientes
create table clientes(
	codigo int auto_increment primary key,
    nombre varchar(25) not null,
    apellido varchar(25) not null,
    cuit varchar(11),
    direccion varchar(50),
    comentarios varchar(140)
);

-- describe retorna el metadato de la tabla
describe clientes;

-- listar registros de la tabla
select * from clientes;

-- inserción de registros
insert into clientes (nombre,apellido,direccion) values
	('Juan','Perez','Lima22');
insert into clientes (nombre,apellido,direccion) values
	('Ana','Gomez','viel 343');
insert into clientes (nombre,apellido,direccion) values
	('Jose','García','peru 342');
insert into clientes (nombre,apellido,direccion) values
	('Beatriz','Perez','chile 34');

-- https://codeshare.io/crios2020

-- 1- Borrar si existe la base de datos Agenda.
drop database if exists Agenda;
-- 2- Crear la base de datos Agenda.
create database Agenda;
-- 3- Ingresar a la base de datos creada.
use Agenda;
-- 4- Crear una tabla llamada "agenda". Debe tener los siguientes campos:
--    nombre (cadena de 20), 
--    domicilio (cadena de 30)
--    telefono (cadena de 11)
create table agenda(
	nombre varchar(20),
    domicilio varchar(20),
    telefono varchar(11)
);
-- 5- Visualizar las tablas existentes en la base de datos para verificar la creación de "agenda".
show tables;
-- 6- Visualizar la estructura de campos de la tabla "agenda". (describe).
describe agenda;
-- 7- Ingresar 10 registros con valores aleatorios.
insert into agenda (nombre, domicilio, telefono) values ('Ana','Lima 34','423423432');
insert into agenda (nombre, domicilio, telefono) values ('Javier','Medrano 345','23423');
insert into agenda (nombre, domicilio, telefono) values ('Juan','Viel 324','243');
-- 8- Seleccione y muestre todos los registros de la tabla:
select * from agenda;
-- Felicitaciones usted ha armado su agenda personal!!!!


