-- Usando la base de datos hr
use hr;
show tables;
select * from COUNTRIES;
select * from REGIONS;
select * from LOCATIONS;
select * from DEPARTMENTS;
select * from EMPLOYEES;

-- Ingresar 5 nuevos paises (countries).
insert into COUNTRIES values
	('UY','Uruguay',2),
    ('EC','Ecuador',2),
    ('CL','Chile',2),
    ('PY','Paraguay',2),
    ('BO','Bolivia',2); 
-- Ingresar 5 nuevas ciudades (locations).
insert into LOCATIONS values
	(3300,'Medrano 162','ad1234','Buenos Aires','Buenos Aires','AR'),
    (3400,'Lima 434','ad1234','Lima','Buenos Aires','AR'),
    (3500,'Perón 984','ad1234','La Falda', 'Córdoba','AR'),
    (3600,'Rivadavia 344','ad1234','Salta','Salta','AR'),
    (3700,'San Martin','ad1234','Levalle','Córdoba','AR');
-- Ingresar 5 nuevos departamentos (departments)
insert into DEPARTMENTS values
	(280, 'Inteligencia de Negocios',null,3300),
    (290, 'Marketing',null,3400),
    (300, 'Planeamiento',null,3500),
    (310, 'Producción',null,3600),
    (320, 'Ventas',null,3700);
-- Ingresar 5 nuevos empleados (employees).
insert into EMPLOYEES values
	(207,'Carlos','Rios','carlos','12345678',curdate(),'AC_ACCOUNT',500000,null,206,280),
    (208,'Juan','Rojas','juan','12345678',curdate(),'AC_ACCOUNT',500000,null,206,280),
    (209,'Pedro','Perez','pedrito','12345678',curdate(),'AC_ACCOUNT',500000,null,206,280),
    (210,'Ana','Rosales','anita','12345678',curdate(),'AC_ACCOUNT',500000,null,206,280),
    (211,'Marina','Riera','mari','12345678',curdate(),'AC_ACCOUNT',500000,null,206,280);
-- Listar todos los empleados mostrando mostrando los datos del departamento de trabajo (departments)
select 	e.EMPLOYEE_ID,concat(e.LAST_NAME,' ',e.FIRST_NAME) nombre, e.EMAIL, e.PHONE_NUMBER,
		e.HIRE_DATE, e.JOB_ID, e.SALARY, e.DEPARTMENT_ID, d.DEPARTMENT_NAME
	from EMPLOYEES e join DEPARTMENTS d on e.DEPARTMENT_ID=d.DEPARTMENT_ID;
-- Listar todos los empleados ordenados por fecha de contratación (hire_date)
-- Listar todos los empleador mostrando antiguedad en años.
-- Mostrar cantidad de empleados por departamento.
-- Listar todos los departamentos mostrando direccion completa (locations,countries,regions).
-- Listar todos los empleados y el nombre del jefe (usar jod_id).
-- Listar todos los empleados que trabajan en departamentos de argentina.
-- Listar todos los departamentos agrupados por ciudad.


